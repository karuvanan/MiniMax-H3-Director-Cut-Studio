"""Dependency-free audio analysis and prompt writing for MiniMax Music 3.

The node consumes ComfyUI's standard AUDIO object.  It intentionally uses only
PyTorch, which is already part of every ComfyUI installation, so installing the
node does not alter the user's Python environment.
"""

from __future__ import annotations

import json
import math
from typing import Any

import torch
import torch.nn.functional as F


_EPS = 1.0e-9


def _finite_float(value: torch.Tensor | float, default: float = 0.0) -> float:
    if isinstance(value, torch.Tensor):
        value = value.detach().float().cpu().item()
    number = float(value)
    return number if math.isfinite(number) else default


def _prepare_audio(audio: dict[str, Any], analysis_sample_rate: int = 12000):
    if not isinstance(audio, dict) or "waveform" not in audio:
        raise ValueError("Expected a ComfyUI AUDIO object with a waveform field.")

    waveform = audio["waveform"]
    if not isinstance(waveform, torch.Tensor):
        waveform = torch.as_tensor(waveform)
    waveform = waveform.detach().float().cpu()

    if waveform.ndim == 1:
        waveform = waveform[None, None, :]
    elif waveform.ndim == 2:
        waveform = waveform[None, :, :]
    elif waveform.ndim != 3:
        raise ValueError(f"Unsupported audio tensor shape: {tuple(waveform.shape)}")

    # ComfyUI AUDIO convention is [batch, channels, samples].  Analyze the first
    # item because LoadAudio produces one item and the prompt describes one song.
    waveform = torch.nan_to_num(waveform[0], nan=0.0, posinf=1.0, neginf=-1.0)
    if waveform.shape[-1] < 32:
        raise ValueError("The reference audio is too short to analyze.")

    source_rate = int(audio.get("sample_rate", 44100))
    if source_rate <= 0:
        raise ValueError(f"Invalid audio sample rate: {source_rate}")

    duration = waveform.shape[-1] / source_rate
    mono = waveform.mean(dim=0)
    peak = mono.abs().max().clamp_min(_EPS)
    mono = mono / peak

    target_rate = min(source_rate, analysis_sample_rate)
    target_samples = max(32, round(mono.numel() * target_rate / source_rate))
    if target_samples != mono.numel():
        mono = F.interpolate(
            mono[None, None, :], size=target_samples, mode="linear", align_corners=False
        )[0, 0]

    return waveform, mono.contiguous(), source_rate, target_rate, duration


def _frame_rms(mono: torch.Tensor, sample_rate: int):
    frame = max(256, int(round(sample_rate * 0.0464)))
    hop = max(64, int(round(sample_rate * 0.0116)))
    if mono.numel() < frame:
        mono = F.pad(mono, (0, frame - mono.numel()))
    frames = mono.unfold(0, frame, hop)
    rms = torch.sqrt(torch.mean(frames * frames, dim=1) + _EPS)
    return rms, hop


def _estimate_tempo(rms: torch.Tensor, envelope_rate: float):
    if rms.numel() < 16:
        return 0.0, 0.0, 0.0

    # Positive energy changes are a useful, inexpensive onset proxy for mixed
    # music.  Centering the envelope makes autocorrelation less sensitive to
    # overall loudness.
    onset = F.relu(rms[1:] - rms[:-1])
    if onset.numel() >= 5:
        onset = F.conv1d(
            onset[None, None, :],
            torch.tensor([0.2, 0.6, 0.2], dtype=onset.dtype)[None, None, :],
            padding=1,
        )[0, 0]
    onset = onset - onset.mean()
    onset_std = onset.std(unbiased=False)
    if onset_std < 1.0e-7:
        return 0.0, 0.0, 0.0
    onset = onset / onset_std

    min_bpm, max_bpm = 70.0, 190.0
    min_lag = max(1, int(envelope_rate * 60.0 / max_bpm))
    max_lag = min(onset.numel() - 2, int(envelope_rate * 60.0 / min_bpm))
    if max_lag <= min_lag:
        return 0.0, 0.0, 0.0

    candidates: list[tuple[float, float]] = []
    for lag in range(min_lag, max_lag + 1):
        left, right = onset[:-lag], onset[lag:]
        denom = torch.sqrt((left.square().sum() * right.square().sum()).clamp_min(_EPS))
        correlation = _finite_float((left * right).sum() / denom)
        bpm = 60.0 * envelope_rate / lag
        # A mild dance-tempo prior only resolves octave ambiguity; it cannot
        # manufacture correlation when the recording has no stable pulse.
        prior = 0.88 + 0.12 * math.exp(-0.5 * ((bpm - 125.0) / 34.0) ** 2)
        candidates.append((correlation * prior, bpm))

    candidates.sort(reverse=True)
    best_score, best_bpm = candidates[0]
    positive_scores = [max(score, 0.0) for score, _ in candidates]
    baseline = sum(positive_scores) / max(1, len(positive_scores))
    confidence = max(0.0, min(1.0, (best_score - baseline) / (abs(best_score) + _EPS)))

    raw_onset = F.relu(rms[1:] - rms[:-1])
    threshold = raw_onset.mean() + raw_onset.std(unbiased=False)
    if raw_onset.numel() >= 3:
        peaks = (
            (raw_onset[1:-1] > raw_onset[:-2])
            & (raw_onset[1:-1] >= raw_onset[2:])
            & (raw_onset[1:-1] > threshold)
        ).sum()
        onset_density = _finite_float(peaks) / max(rms.numel() / envelope_rate, _EPS)
    else:
        onset_density = 0.0
    return best_bpm, confidence, onset_density


def _spectral_features(mono: torch.Tensor, sample_rate: int):
    n_fft = 1024 if sample_rate >= 8000 else 512
    hop = n_fft // 4
    if mono.numel() < n_fft:
        mono = F.pad(mono, (0, n_fft - mono.numel()))
    window = torch.hann_window(n_fft, dtype=mono.dtype)
    # Use the mean magnitude spectrum for descriptive balance. A power spectrum
    # is useful for energy accounting but over-weights dominant kick/sub bins and
    # can make a full, bright master look implausibly dark in the written prompt.
    spectrum = torch.stft(
        mono,
        n_fft=n_fft,
        hop_length=hop,
        win_length=n_fft,
        window=window,
        center=True,
        return_complex=True,
    ).abs().mean(dim=1)
    frequencies = torch.linspace(0.0, sample_rate / 2.0, spectrum.numel())
    total = spectrum.sum().clamp_min(_EPS)
    centroid = _finite_float((frequencies * spectrum).sum() / total)
    low_ratio = _finite_float(spectrum[frequencies < 220.0].sum() / total)
    high_ratio = _finite_float(spectrum[frequencies > 4000.0].sum() / total)
    cumulative = torch.cumsum(spectrum, dim=0)
    rolloff_index = int(torch.searchsorted(cumulative, total * 0.85).clamp_max(spectrum.numel() - 1))
    rolloff = _finite_float(frequencies[rolloff_index])
    return centroid, rolloff, low_ratio, high_ratio


def _energy_curve(rms: torch.Tensor, section_count: int = 6):
    if rms.numel() == 0:
        return [0.0] * section_count, "steady"
    sections = []
    for index in range(section_count):
        start = round(index * rms.numel() / section_count)
        end = max(start + 1, round((index + 1) * rms.numel() / section_count))
        sections.append(_finite_float(rms[start:end].mean()))
    peak = max(sections) or _EPS
    normalized = [round(value / peak, 3) for value in sections]
    spread = max(normalized) - min(normalized)
    if spread < 0.12:
        shape = "steady"
    elif normalized[-1] - normalized[0] > 0.20:
        shape = "rising"
    elif normalized[0] - normalized[-1] > 0.20:
        shape = "descending"
    elif max(range(section_count), key=normalized.__getitem__) in (2, 3, 4):
        shape = "build-peak-release"
    else:
        shape = "contrasting"
    return normalized, shape


def _describe_features(features: dict[str, Any]):
    centroid = features["spectral_centroid_hz"]
    low_ratio = features["low_frequency_ratio"]
    dynamics = features["dynamic_range_db"]
    onset_density = features["onset_density_per_second"]
    stereo_width = features["stereo_width_ratio"]

    tone = "dark and warm" if centroid < 1700 else "balanced and present" if centroid < 3100 else "bright and crisp"
    bass = "powerful low-end emphasis" if low_ratio > 0.52 else "firm low-end weight" if low_ratio > 0.32 else "lean, controlled low end"
    groove = "rapid, highly articulated rhythmic activity" if onset_density > 4.0 else "active syncopated rhythmic movement" if onset_density > 2.0 else "spacious, clearly separated rhythmic accents"
    dynamic = "strong sectional contrast" if dynamics > 13.0 else "moderate dynamic contrast" if dynamics > 7.0 else "dense, consistently controlled loudness"
    width = "wide stereo staging" if stereo_width > 0.45 else "moderately wide stereo staging" if stereo_width > 0.18 else "focused central stereo staging"
    return tone, bass, groove, dynamic, width


def _tempo_phrase(bpm: float, confidence: float):
    if bpm <= 0:
        return "A clearly defined tempo guided by the source pulse"
    if confidence >= 0.32:
        return f"Approximately {round(bpm):d} BPM"
    lower = max(55, int(round((bpm - 8.0) / 5.0) * 5))
    upper = min(210, int(round((bpm + 8.0) / 5.0) * 5))
    return f"A tempo in the approximate {lower}-{upper} BPM range"


def _lyrics_for_duration(duration: float, vocal_mode: str, override: str):
    if override.strip():
        return override.strip()
    if duration <= 25.0:
        sections = ["Intro", "Hook", "Break", "Final Hook", "Outro"]
    elif duration <= 70.0:
        sections = ["Intro", "Build Up", "Hook", "Instrumental", "Break", "Final Hook", "Outro"]
    else:
        sections = ["Intro", "Verse", "Pre-Chorus", "Chorus", "Instrumental", "Bridge", "Final Chorus", "Outro"]

    lines: list[str] = []
    for section in sections:
        lines.append(f"[{section}]")
        if vocal_mode == "instrumental":
            lines.append("[Instrumental]")
        elif vocal_mode == "vocal_chops":
            lines.append("(wordless original vocal chops)")
        lines.append("")
    return "\n".join(lines).strip()


def _build_caption(
    features: dict[str, Any],
    genre_hint: str,
    creative_direction: str,
    vocal_mode: str,
    reference_strength: str,
):
    tone, bass, groove, dynamic, width = _describe_features(features)
    tempo = _tempo_phrase(features["estimated_bpm"], features["tempo_confidence"])
    genre = genre_hint.strip() or "rhythm-forward contemporary electronic music"
    direction = creative_direction.strip()
    direction_sentence = f" Creative direction: {direction.rstrip('.')}." if direction else ""

    preserve = {
        "loose": "Use only the broad pace and energy profile as inspiration; create a substantially different groove, melody, harmony, and arrangement.",
        "balanced": "Preserve the approximate pulse, rhythmic density, and energy contour while creating an original groove, melody, harmony, and arrangement.",
        "close": "Closely follow the measured pulse, rhythmic density, sectional contrast, and energy contour, while keeping every melody, harmony, hook, lyric, and instrumental phrase newly composed.",
    }[reference_strength]

    if vocal_mode == "instrumental":
        vocal = (
            "The piece is instrumental. No lead singer, spoken words, or intelligible vocal phrases. "
            "Let a distinctive synthesizer, guitar, keyboard, or other timbrally appropriate instrument carry the lead melodic role."
        )
    elif vocal_mode == "vocal_chops":
        vocal = (
            "Use sparse, newly created, non-lexical vocal chops as rhythmic texture rather than continuous lead singing. "
            "Keep them tightly edited, energetic, and integrated with the percussion; use restrained widening and short ambience. "
            "Do not reproduce any recognizable lyric, vocal phrase, or melody from the analyzed recording."
        )
    else:
        vocal = (
            "Use an expressive lead performance appropriate to the supplied lyrics, with a stable vocal identity, controlled doubles in larger sections, "
            "and restrained delay and reverb. Keep diction clear and let backing vocals appear only when the arrangement expands."
        )

    curve = features["energy_curve_shape"]
    if curve == "rising":
        timeline = "continually add rhythmic and harmonic layers toward the final peak"
    elif curve == "descending":
        timeline = "open at full impact, then progressively remove layers and leave a controlled final release"
    elif curve == "build-peak-release":
        timeline = "build through the middle sections, reach a concentrated late peak, and release cleanly in the outro"
    elif curve == "contrasting":
        timeline = "alternate compact low-density passages with decisive high-energy returns"
    else:
        timeline = "maintain a stable core groove while creating interest through timbral and textural changes"

    caption = f"""Global Metadata: {genre}. {tempo}, with {groove}. The overall spectrum is {tone}, supported by {bass}, {dynamic}, and {width}. Follow a {curve.replace('-', ' ')} emotional and energy profile suited to precise visual editing and clear musical hit points. Use polished modern production with controlled transients, an uncluttered center, and enough contrast for each structural change to read immediately. {preserve}{direction_sentence}

Vocal Details: {vocal}

Arrangement: Intro: establish the tempo and sonic identity immediately with a compact motif, filtered texture, or isolated rhythmic accent; avoid a long ambient lead-in. First development: introduce the core drums and bass in stages, keeping the principal hook clearly separated from supporting details. Main section: present a new, memorable lead motif over the full groove, using the measured spectral balance and stereo character without copying the analyzed recording. Transition: create a short drop, stop, fill, reverse texture, or harmonic suspension that produces a clean edit point. Contrast section: reduce the texture to bass, percussion, and one identifying timbre, then rebuild with a meaningful variation rather than a literal repeat. Final section: {timeline}; strengthen the last return with one additional counterline, percussion layer, or widened harmonic element. Outro: end with a deliberate final accent or a short natural decay appropriate to the energy curve. Keep instrument entrances and exits continuous, make every transition musically motivated, and avoid reproducing any source melody, exact hook, lyric, or arrangement."""
    return caption


class Music3AudioReferenceAnalyzer:
    """Analyze reference audio and write a Music 3 structured caption."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio": ("AUDIO",),
                "genre_hint": (
                    "STRING",
                    {
                        "default": "high-energy theatrical electronic dance-pop, club and performance-edit influences",
                        "multiline": True,
                    },
                ),
                "creative_direction": (
                    "STRING",
                    {
                        "default": "Create a new choreographic track with strong visual hit points and an original hook",
                        "multiline": True,
                    },
                ),
                "vocal_mode": (["instrumental", "vocal_chops", "full_song"],),
                "reference_strength": (["balanced", "loose", "close"],),
                "duration_mode": (["match_reference", "fixed"],),
                "fixed_duration": ("INT", {"default": 20, "min": 5, "max": 300, "step": 1}),
                "lyrics_override": ("STRING", {"default": "", "multiline": True}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "STRING", "FLOAT", "FLOAT", "INT")
    RETURN_NAMES = ("caption", "lyrics", "analysis_json", "estimated_bpm", "source_duration", "suggested_duration")
    FUNCTION = "analyze"
    CATEGORY = "audio/MiniMax Music 3"

    def analyze(
        self,
        audio,
        genre_hint,
        creative_direction,
        vocal_mode,
        reference_strength,
        duration_mode,
        fixed_duration,
        lyrics_override,
    ):
        waveform, mono, source_rate, analysis_rate, duration = _prepare_audio(audio)
        rms, hop = _frame_rms(mono, analysis_rate)
        bpm, tempo_confidence, onset_density = _estimate_tempo(rms, analysis_rate / hop)
        centroid, rolloff, low_ratio, high_ratio = _spectral_features(mono, analysis_rate)
        curve, curve_shape = _energy_curve(rms)

        overall_rms = torch.sqrt(torch.mean(mono.square()) + _EPS)
        peak = mono.abs().max().clamp_min(_EPS)
        crest_db = 20.0 * math.log10(_finite_float(peak / overall_rms, 1.0) + _EPS)
        rms_db = 20.0 * torch.log10(rms.clamp_min(_EPS))
        dynamic_range = _finite_float(torch.quantile(rms_db, 0.90) - torch.quantile(rms_db, 0.10))

        if waveform.shape[0] >= 2:
            mid = 0.5 * (waveform[0] + waveform[1])
            side = 0.5 * (waveform[0] - waveform[1])
            stereo_width = _finite_float(
                torch.sqrt(torch.mean(side.square()) + _EPS)
                / torch.sqrt(torch.mean(mid.square()) + _EPS)
            )
        else:
            stereo_width = 0.0

        suggested_duration = (
            int(max(5, min(300, round(duration))))
            if duration_mode == "match_reference"
            else int(fixed_duration)
        )
        features = {
            "source_duration_seconds": round(duration, 3),
            "source_sample_rate": source_rate,
            "channels": int(waveform.shape[0]),
            "estimated_bpm": round(bpm, 2),
            "tempo_confidence": round(tempo_confidence, 3),
            "onset_density_per_second": round(onset_density, 3),
            "spectral_centroid_hz": round(centroid, 1),
            "spectral_rolloff_85_hz": round(rolloff, 1),
            "low_frequency_ratio": round(low_ratio, 4),
            "high_frequency_ratio": round(high_ratio, 4),
            "crest_factor_db": round(crest_db, 2),
            "dynamic_range_db": round(dynamic_range, 2),
            "stereo_width_ratio": round(stereo_width, 3),
            "energy_curve": curve,
            "energy_curve_shape": curve_shape,
            "suggested_duration_seconds": suggested_duration,
            "analysis_limits": [
                "Tempo is an estimate and may resolve to half-time or double-time.",
                "A mixed track cannot reliably reveal vocal gender, exact genre, key, or individual instruments without a learned classifier or stem separation.",
                "The generated song is text-conditioned; the source waveform is not passed into MiniMax Music 3 conditioning.",
            ],
        }
        caption = _build_caption(
            features,
            genre_hint,
            creative_direction,
            vocal_mode,
            reference_strength,
        )
        lyrics = _lyrics_for_duration(suggested_duration, vocal_mode, lyrics_override)
        report = json.dumps(features, ensure_ascii=False, indent=2)
        return caption, lyrics, report, float(bpm), float(duration), suggested_duration


class Music3AudioReferenceEncode(Music3AudioReferenceAnalyzer):
    """Analyze audio, write the prompt, and run Music 3 text encoding.

    Current ComfyUI builds expose MiniMaxMusic3TextEncode.caption and .lyrics as
    non-connectable widgets. This composite node follows the official encoder
    implementation internally, allowing generated strings to reach the encoder
    without a fragile frontend-only widget conversion.
    """

    @classmethod
    def INPUT_TYPES(cls):
        analyzer_inputs = super().INPUT_TYPES()["required"]
        return {
            "required": {
                "audio": analyzer_inputs["audio"],
                "clip": ("CLIP",),
                "genre_hint": analyzer_inputs["genre_hint"],
                "creative_direction": analyzer_inputs["creative_direction"],
                "vocal_mode": analyzer_inputs["vocal_mode"],
                "reference_strength": analyzer_inputs["reference_strength"],
                "duration_mode": analyzer_inputs["duration_mode"],
                "fixed_duration": analyzer_inputs["fixed_duration"],
                "lyrics_override": analyzer_inputs["lyrics_override"],
                "seed": (
                    "INT",
                    {
                        "default": 0,
                        "min": 0,
                        "max": 0xFFFFFFFFFFFFFFFF,
                        "control_after_generate": True,
                    },
                ),
                "cfg_scale": ("FLOAT", {"default": 1.7, "min": 0.0, "max": 100.0, "step": 0.1}),
                "top_k": ("INT", {"default": 50, "min": 1, "max": 16384}),
            }
        }

    RETURN_TYPES = (
        "CONDITIONING",
        "FLOAT",
        "STRING",
        "STRING",
        "STRING",
        "FLOAT",
        "FLOAT",
        "INT",
    )
    RETURN_NAMES = (
        "conditioning",
        "seconds",
        "caption",
        "lyrics",
        "analysis_json",
        "estimated_bpm",
        "source_duration",
        "suggested_duration",
    )
    FUNCTION = "analyze_and_encode"

    def analyze_and_encode(
        self,
        audio,
        clip,
        genre_hint,
        creative_direction,
        vocal_mode,
        reference_strength,
        duration_mode,
        fixed_duration,
        lyrics_override,
        seed,
        cfg_scale,
        top_k,
    ):
        caption, lyrics, report, bpm, source_duration, suggested_duration = self.analyze(
            audio,
            genre_hint,
            creative_direction,
            vocal_mode,
            reference_strength,
            duration_mode,
            fixed_duration,
            lyrics_override,
        )

        # Keep this in sync with ComfyUI's built-in MiniMaxMusic3TextEncode.
        # Import lazily so the analyzer remains testable outside a ComfyUI tree.
        from comfy.ldm.minimax_music.ar import AUDIO_FRAMES_PER_SECOND, MAX_AUDIO_FRAMES

        max_audio_frames = min(
            MAX_AUDIO_FRAMES,
            max(1, round(float(suggested_duration) * AUDIO_FRAMES_PER_SECOND)),
        )
        tokens = clip.tokenize(
            caption,
            lyrics=lyrics,
            seed=int(seed),
            max_audio_frames=max_audio_frames,
            cfg_scale=float(cfg_scale),
            top_k=int(top_k),
        )
        conditioning = clip.encode_from_tokens_scheduled(tokens)
        for cond in conditioning:
            hidden = cond[0]
            cond[1]["conditioning_scale"] = torch.ones(
                (hidden.shape[0], 1, 1),
                device=hidden.device,
                dtype=hidden.dtype,
            )
        seconds = conditioning[0][0].shape[1] / AUDIO_FRAMES_PER_SECOND
        return (
            conditioning,
            float(seconds),
            caption,
            lyrics,
            report,
            bpm,
            source_duration,
            suggested_duration,
        )
