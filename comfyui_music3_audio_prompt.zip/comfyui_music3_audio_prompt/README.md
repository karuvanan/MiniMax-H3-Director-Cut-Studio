# Music 3 Audio Reference Analyzer for ComfyUI

This custom node turns a loaded audio file into a MiniMax Music 3 Structured
Caption. It analyzes the waveform locally and returns:

- `caption`: `Global Metadata`, `Vocal Details`, and `Arrangement`
- `lyrics`: generated section tags or the exact override supplied by the user
- `analysis_json`: measurements plus explicit analysis limitations
- estimated BPM, source duration, and suggested generation duration

The source waveform is not used as model conditioning. Music 3 remains
text-conditioned; these nodes convert measurable reference characteristics into
its text conditioning format.

Two nodes are included:

- `Music 3 Audio Reference Analyzer`: emits caption and lyrics strings for
  diagnostics or frontends that support string-to-widget links.
- `Music 3 Audio Reference Encode`: recommended for current ComfyUI builds. It
  combines analysis, prompt writing, and the official Music 3 text-encoding
  operation because the built-in Caption and Lyrics widgets are not connectable.

## Install

1. Copy the complete `comfyui_music3_audio_prompt` folder to:
   `ComfyUI/custom_nodes/comfyui_music3_audio_prompt`
2. Restart ComfyUI.
3. Confirm that `Music 3 Audio Reference Analyzer` and
   `Music 3 Audio Reference Encode` appear under
   `audio/MiniMax Music 3`.

No additional Python packages are required. The node uses ComfyUI's own PyTorch.

## Use the supplied API workflow

1. Copy the reference MP3 into `ComfyUI/input/`.
2. If necessary, change node `1.inputs.audio` in
   `audio_minimax_music_3_auto_prompt_api.json` to the uploaded filename.
3. Queue the API workflow. The supplied workflow uses the combined Encode node,
   so no `Convert Widget to Input` action is needed.
4. Inspect `analysis_json` in the UI when diagnosing a questionable tempo or
   description. For reliable artistic identity, fill in `genre_hint` and
   `creative_direction`; waveform heuristics cannot identify exact genres or
   instruments.

## Controls

- `vocal_mode`: instrumental, non-lexical vocal chops, or a full song.
- `reference_strength`: controls how strongly the caption asks Music 3 to follow
  the measured tempo, rhythmic density, and energy contour.
- `duration_mode`: match the source duration or use `fixed_duration`.
- `lyrics_override`: when non-empty, it is passed through exactly, including
  supported section tags.

## Recommended graph connections

```text
LoadAudio.AUDIO --------------------> Music3AudioReferenceEncode.audio
CLIPLoader.CLIP --------------------> Music3AudioReferenceEncode.clip
Music3AudioReferenceEncode.conditioning -> ConditioningZeroOut.conditioning
Music3AudioReferenceEncode.conditioning -> KSampler.positive
Music3AudioReferenceEncode.seconds -----> EmptyMiniMaxMusic3LatentAudio.seconds
```

The built-in `MiniMaxMusic3TextEncode` node is replaced by the combined node.
