from .nodes import Music3AudioReferenceAnalyzer, Music3AudioReferenceEncode


NODE_CLASS_MAPPINGS = {
    "Music3AudioReferenceAnalyzer": Music3AudioReferenceAnalyzer,
    "Music3AudioReferenceEncode": Music3AudioReferenceEncode,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "Music3AudioReferenceAnalyzer": "Music 3 Audio Reference Analyzer",
    "Music3AudioReferenceEncode": "Music 3 Audio Reference Encode",
}


__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
